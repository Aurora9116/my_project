package api

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
	"system_work/http_code"
	"system_work/middlerware"
	"system_work/models"
	"system_work/service"
)

type admin struct {
}

var Admin = new(admin)

// AddAdmin 注册管理员
func (*admin) AddAdmin(c *gin.Context) {
	var data models.Admin
	err := c.ShouldBindJSON(&data)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	err = service.Admin.CheckAdmin(data.Username)
	if err == http_code.ErrAdminFound || err != http_code.ErrAdminNotFound {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	data.Password = service.Utils.GetPassword(data.Password)
	err = service.Admin.RegisterAdmin(data)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "管理员已添加",
	})
}

// LoginAdmin 管理员登录
func (*admin) LoginAdmin(c *gin.Context) {
	var data models.Admin
	err := c.ShouldBindJSON(&data)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	err = service.Admin.LoginAdmin(data)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	token, err := middlerware.GetToken(data.Username)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg":   "登录成功",
		"token": token,
	})

}

// DeleteAdmin 删除管理员
func (*admin) DeleteAdmin(c *gin.Context) {

}

// AddRoom 录入房间
func (*admin) AddRoom(c *gin.Context) {
	var roomBasic models.RoomBasic
	err := c.ShouldBindJSON(&roomBasic)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	err = service.Room.AddRoom(&roomBasic)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "房间已添加",
	})
}

// DeleteRoom 删除房间
func (*admin) DeleteRoom(c *gin.Context) {
	roomID, err := strconv.Atoi(c.PostForm("roomID"))
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	err = service.Room.DeleteRoom(roomID)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "房间已删除",
	})
}

// GetRoomStatus 查看房间状态
func (*admin) GetRoomStatus(c *gin.Context) {
	roomID, err := strconv.Atoi(c.Query("roomID"))
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	message, err := service.Room.GetRoomStatus(roomID)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": message,
	})
}
