package service

import (
	"golang.org/x/crypto/bcrypt"
	"log"
	"time"
)

type utils struct{}

var Utils = new(utils)

// GetTimeDay 计算time1到现在过了多少天（向下取整）
func (*utils) GetTimeDay(time1 time.Time) int {
	time2 := int(time.Now().Sub(time1).Hours())
	day := time2 / 24
	if time2%24 == 0 {
		return day
	}
	return day + 1
}

// CompareTime 比较时间是否相等 true为相等
func (*utils) CompareTime(time1 time.Time, time2 time.Time) bool {
	time3 := time1.Sub(time2).Minutes()
	if int(time3) == 0 {
		return true
	}
	return false
}

// ComparePwd 比对密码
func (*utils) ComparePwd(pwd1 string, pwd2 string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(pwd1), []byte(pwd2))
	if err != nil {
		return false
	} else {
		return true
	}
}

// GetPassword 生成密码
func (*utils) GetPassword(password string) string {
	Password, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost) //加密处理
	if err != nil {
		log.Println(err)
	}
	return string(Password)
}
