package models

import (
	"gorm.io/gorm"
	"time"
)

type CheckOut struct {
	gorm.Model
	Price        float64   `json:"price" gorm:"column:price;type:float"`
	Deposit      int       `json:"deposit" gorm:"column:deposit;type:int(100)"`
	Username     string    `json:"username" gorm:"column:username;type:varchar(100)"`
	RoomID       int       `json:"room_id" gorm:"column:room_id;type:int(100)"`
	DocumentType string    `json:"document_type" gorm:"column:document_type;type:varchar(100)"`
	DocumentID   string    `json:"document_id" gorm:"column:document_id;type:varchar(100)"`
	LeaveTime    time.Time `json:"leave_time" gorm:"column:leave_time;type:datetime"`
}

func (*CheckOut) TableName() string {
	return "check_out"
}
