package api

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
	"system_work/http_code"
	"system_work/models"
	"system_work/service"
)

type book struct {
}

var Book = new(book)

// AddUser 预订房间
func (*book) AddUser(c *gin.Context) {
	var data models.Appointment
	err := c.ShouldBindJSON(&data)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	Utils.AddUser(c, data, http_code.RoomStatusWillOccupied)
}

// DeleteUserBook 解除预订
func (*book) DeleteUserBook(c *gin.Context) {
	roomID, err := strconv.Atoi(c.PostForm("roomID"))
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	_, deposit, err := service.User.DeleteUserBook(roomID)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code":    200,
		"deposit": deposit, // 押金
	})
}
