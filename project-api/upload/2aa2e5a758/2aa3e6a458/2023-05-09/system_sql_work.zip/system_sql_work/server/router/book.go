package router

import (
	"github.com/gin-gonic/gin"
	"system_work/api"
)

type Book struct {
}

// BookGroup 预订
func (*Book) BookGroup(routerGroup *gin.RouterGroup) {
	bookGroup := routerGroup.Group("/book")
	{
		bookGroup.POST("/add", api.Book.AddUser)
		bookGroup.POST("/delete", api.Book.DeleteUserBook)
		// todo 预订的时间到了，为用户发放房间卡，以及修改房间状态
	}
}
