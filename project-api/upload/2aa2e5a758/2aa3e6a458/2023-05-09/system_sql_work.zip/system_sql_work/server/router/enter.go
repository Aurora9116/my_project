package router

type RouteGroup struct {
	Reception
	Book
	Admin
	Info
	Form
}

var Router = new(RouteGroup)
