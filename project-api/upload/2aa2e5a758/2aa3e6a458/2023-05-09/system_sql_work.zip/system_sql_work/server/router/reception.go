package router

import (
	"github.com/gin-gonic/gin"
	"system_work/api"
)

type Reception struct {
}

// ReceptionGroup 前台操作
func (*Reception) ReceptionGroup(routerGroup *gin.RouterGroup) {
	receptionGroup := routerGroup.Group("/user")
	{
		receptionGroup.POST("/add", api.User.AddUser)
		receptionGroup.POST("/delete", api.User.DeleteUserForPay)
		//receptionGroup.GET("/status", api.User.GetRoomStatus)
	}
}
