package models

import "gorm.io/gorm"

type RoomBasic struct {
	gorm.Model
	RoomID   int     `json:"room_id" gorm:"index;column:room_id;type:int(100);"`
	RoomType string  `json:"room_type" gorm:"column:room_type;type:varchar(100)"`
	Price    float64 `json:"price" gorm:"column:price;type:float"`
	Deposit  int     `json:"deposit" gorm:"column:deposit;type:int"`
	Status   int     `json:"status" gorm:"column:status; type:int"`
}

func (*RoomBasic) TableName() string {
	return "room_basic"

}
