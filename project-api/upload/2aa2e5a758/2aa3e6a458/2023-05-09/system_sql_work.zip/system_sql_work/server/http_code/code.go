package http_code

import (
	"errors"
)

var (
	ErrUserNotFound        = errors.New("用户未找到")
	ErrUserFound           = errors.New("用户已存在")
	ErrRoomFound           = errors.New("房间已存在")
	ErrRoomNotFound        = errors.New("房间不存在")
	ErrRoomNotFree         = errors.New("无空闲房间")
	ErrRoomOccupied        = errors.New("房间正在被使用")
	ErrRoomWillOccupied    = errors.New("房间被预订")
	ErrRoomStatus          = errors.New("房间状态错误")
	ErrAdminFound          = errors.New("管理员已存在")
	ErrAdminNotFound       = errors.New("管理员不存在")
	ErrTokenTypeWrong      = errors.New("token类型错误")
	ErrTokenWrong          = errors.New("token错误")
	ErrTokenRuntime        = errors.New("token超时")
	ErrTokenNotExist       = errors.New("token不存在")
	ErrPasswordErrPassword = errors.New("密码错误")
)

const (
	RoomStatusNotExist     = -1
	RoomStatusFree         = 0
	RoomStatusOccupied     = 1
	RoomStatusWillOccupied = 2
)

func RoomStatus(status int) string {
	if status == RoomStatusNotExist {
		return "房间不存在"
	}
	if status == RoomStatusFree {
		return "房间空闲"
	}
	if status == RoomStatusOccupied {
		return "房间被使用"
	}
	if status == RoomStatusWillOccupied {
		return "房间被预订"
	}
	return "房间状态错误"
}
