package conf

import (
	"fmt"
	"github.com/spf13/viper"
)

type Conf struct {
	Mysql NewMysql `yaml:"mysql" json:"mysql"`
}

type NewMysql struct {
	Dsn string `yaml:"dsn" json:"dsn"`
}

var conf Conf

func GetConf() Conf {
	return conf
}

func Init() error {
	viper.SetConfigType("yaml")
	viper.SetConfigFile("./config.yaml")
	//viper.SetConfigName("config")
	//viper.AddConfigPath(".")
	// 读取配置文件
	err := viper.ReadInConfig()
	if err != nil {
		fmt.Println(err)
	}
	err = viper.Unmarshal(&conf)
	return err

}
