package main

import (
	"log"
	"system_work/conf"
	"system_work/initialize"
)

func main() {
	err := conf.Init()
	if err != nil {
		log.Println(err)
	}
	initialize.Init()

}
