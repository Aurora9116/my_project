package models

import "gorm.io/gorm"

type Admin struct {
	Username string `json:"username" gorm:"column:username;type:varchar(100)"`
	Password string `json:"password" gorm:"column:password;type:varchar(100)"`
	//Role int
	AdminID int `gorm:"column:admin_id"`
	gorm.Model
}

func (*Admin) TableName() string {
	return "admin"
}
