package api

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"system_work/http_code"
	"system_work/models"
	"system_work/service"
)

type utils struct {
}

var Utils = new(utils)

func (u *utils) AddUser(c *gin.Context, data models.Appointment, status int) {
	err := service.User.CheckUser(data.Username, data.DocumentType, data.DocumentID)
	if err != http_code.ErrUserNotFound {
		u.ErrJSON(c, http.StatusOK, err)
		return
	}
	room, err := service.User.AddUser(data, status)
	if err != nil {
		u.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code": 200,
		"房间号":  room.RoomID,
	})
}

func (*utils) CheckUserJSON(c *gin.Context, info []*models.UserRoom) {
	c.JSON(http.StatusOK, gin.H{
		"user": info,
		"code": 200,
	})
}

func (*utils) ErrJSON(c *gin.Context, httpCode int, err error) {
	c.JSON(httpCode, gin.H{
		"msg": err.Error(),
	})
}
