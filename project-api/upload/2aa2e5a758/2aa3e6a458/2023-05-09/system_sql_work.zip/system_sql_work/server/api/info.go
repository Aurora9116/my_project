package api

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"system_work/service"
)

type info struct {
}

var Info = new(info)

// LivingInfo 查询在住客人信息
func (*info) LivingInfo(c *gin.Context) {
	data, err := service.User.LivingInfo()
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	Utils.CheckUserJSON(c, data)
}

// BookInfo 查询预订客人信息
func (*info) BookInfo(c *gin.Context) {
	data, err := service.User.BookInfo()
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	Utils.CheckUserJSON(c, data)
}

// HistoryInfo 查询预订客人信息
func (*info) HistoryInfo(c *gin.Context) {
	data, err := service.User.HistoryInfo()
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	Utils.CheckUserJSON(c, data)
}
