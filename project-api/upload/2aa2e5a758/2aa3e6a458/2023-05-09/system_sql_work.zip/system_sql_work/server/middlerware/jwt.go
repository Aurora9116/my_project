package middlerware

import (
	"github.com/dgrijalva/jwt-go"
	"github.com/gin-gonic/gin"
	"net/http"
	"strings"
	"system_work/http_code"
	"time"
)

var JwtKey = []byte("sf3513sdf1da")

type MyClaims struct {
	Username string
	jwt.StandardClaims
}

// GetToken 生成JWT
func GetToken(username string) (string, error) {
	expireTime := time.Now().Add(7 * time.Hour * 24)
	SetClaims := MyClaims{
		username,
		jwt.StandardClaims{
			ExpiresAt: expireTime.Unix(), // 过期时间
			Issuer:    "Aurora",          // 签发人
		},
	}
	// 使用指定的签名方法创建签名对象
	reqClaims := jwt.NewWithClaims(jwt.SigningMethodHS256, SetClaims)
	// 使用指定的JwtKey签名并获得完整的编码后的字符串token
	token, err := reqClaims.SignedString(JwtKey)
	if err != nil {
		return "", err
	}
	return token, nil
}

// CheckToken 验证JWT
func CheckToken(tokenString string) (*MyClaims, error) {
	// 解析token
	token, _ := jwt.ParseWithClaims(tokenString, &MyClaims{}, func(token *jwt.Token) (interface{}, error) {
		return JwtKey, nil
	})
	if claims, ok := token.Claims.(*MyClaims); ok && token.Valid {
		return claims, nil
	}
	return nil, http_code.ErrTokenWrong
}

// JwtToken JWT中间件
func JwtToken() gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenHandler := c.GetHeader("Authorization")
		if tokenHandler != "" {
			checkToken := strings.SplitN(tokenHandler, " ", 2)
			if len(checkToken) != 2 || checkToken[0] != "Bearer" {
				json(c, http_code.ErrTokenTypeWrong)
				c.Abort()
				return
			}
			key, err := CheckToken(checkToken[1])
			if err == http_code.ErrTokenWrong {
				json(c, err)
				c.Abort()
				return
			}
			if time.Now().Unix() > key.ExpiresAt {
				err = http_code.ErrTokenRuntime
				json(c, err)
				c.Abort()
				return
			}
			c.Set("username", key.Username)
			c.Next()
			c.Abort()
			return
		}
		c.JSON(http.StatusOK, gin.H{"message": http_code.ErrTokenNotExist.Error()})
		c.Abort()
		return
	}
}

func json(c *gin.Context, err error) {
	c.JSON(http.StatusOK, gin.H{
		"message": err.Error(),
	})
}
