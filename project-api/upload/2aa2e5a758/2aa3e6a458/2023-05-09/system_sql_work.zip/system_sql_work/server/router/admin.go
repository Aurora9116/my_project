package router

import (
	"github.com/gin-gonic/gin"
	"system_work/api"
	"system_work/middlerware"
)

type Admin struct {
}

// AdminGroup 前台操作
func (*Admin) AdminGroup(routerGroup *gin.RouterGroup) {
	adminGroup := routerGroup.Group("/admin")
	{
		// todo
		adminGroup.POST("/add", api.Admin.AddAdmin)
		adminGroup.POST("/login", api.Admin.LoginAdmin)
		//adminGroup.POST("/delete", api.Admin.DeleteAdmin)
	}
	adminRoomGroup := routerGroup.Group("/admin/room")
	adminGroup.Use(middlerware.JwtToken())
	{
		adminRoomGroup.POST("/add", api.Admin.AddRoom)
		adminRoomGroup.POST("/delete", api.Admin.DeleteRoom)
		adminRoomGroup.GET("/status", api.Admin.GetRoomStatus)
	}
}
