package api

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"system_work/service"
)

type form struct {
}

var Form = new(form)

// HistoryRoomInfo 开房记录统计
func (*form) HistoryRoomInfo(c *gin.Context) {
	data, err := service.User.HistoryInfo()
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	Utils.CheckUserJSON(c, data)
}

// PayInfo 退房结账报表
func (*form) PayInfo(c *gin.Context) {
	data, err := service.User.PayInfo()
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"user": data,
		"code": 200,
	})
}

// BookRoomInfo 预订房间报表
func (*form) BookRoomInfo(c *gin.Context) {
	data, err := service.User.BookRoomInfo()
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"user": data,
		"code": 200,
	})
}
