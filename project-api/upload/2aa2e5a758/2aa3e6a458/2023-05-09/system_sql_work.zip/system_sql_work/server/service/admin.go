package service

import (
	"system_work/dao"
	"system_work/http_code"
	"system_work/models"
)

type admin struct{}

var Admin = new(admin)

func (*admin) RegisterAdmin(data models.Admin) error {
	return dao.DB.Debug().Create(&data).Error
}

func (*admin) CheckAdmin(username string) error {
	var data models.Admin
	err := dao.DB.Debug().Where("username = ?", username).Find(&data).Error
	if err != nil {
		return err
	}
	if data.Username == username {
		return http_code.ErrAdminFound
	}
	return http_code.ErrAdminNotFound
}

func (*admin) LoginAdmin(data models.Admin) error {
	var data1 models.Admin
	err := dao.DB.Debug().Where("username = ?", data.Username).Find(&data1).Error
	if err != nil {
		return err
	}
	if Utils.ComparePwd(data1.Password, data.Password) {
		return nil
	}
	return http_code.ErrPasswordErrPassword
}
