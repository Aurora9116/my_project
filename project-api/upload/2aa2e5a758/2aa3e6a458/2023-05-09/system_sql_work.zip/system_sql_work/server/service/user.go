package service

import (
	"system_work/dao"
	"system_work/http_code"
	"system_work/models"
	"time"
)

type user struct{}

var User = new(user)

// AddUser 添加用户
func (u *user) AddUser(data models.Appointment, status int) (*models.RoomBasic, error) {

	roomData, err := Room.CheckRoom(data.RoomType, data.RoomID)
	if err != nil {
		return nil, err
	}

	person := &models.UserBasic{
		Username:     data.Username,
		Sex:          data.Sex,
		DocumentType: data.DocumentType,
		DocumentID:   data.DocumentID,
		Phone:        data.Phone,
	}

	startTime, _ := time.ParseInLocation("2006-01-02 15:04:05", data.StartTime, time.Local)
	if status == http_code.RoomStatusOccupied {
		startTime = time.Now()
	}
	exLeaveTime, _ := time.ParseInLocation("2006-01-02 15:04:05", data.ExLeaveTime, time.Local)

	userRoom := &models.UserRoom{
		DocumentIdentity: data.DocumentID,
		RoomIdentity:     data.RoomID,
		StartTime:        startTime,
		ExLeaveTime:      exLeaveTime,
		User:             person,
	}
	err = dao.DB.Debug().Create(&userRoom).Error
	if err != nil {
		return nil, err
	}
	// 更新房间状态
	err = Room.UpdateRoomStatus(roomData, status)
	if err != nil {
		return nil, err
	}
	return roomData, nil
}

// CheckUser 检查用户是否存在
func (u *user) CheckUser(username string, documentType string, documentID string) error {
	var user1 models.UserBasic
	err := dao.DB.Where("document_type = ? and document_id = ?", documentType, documentID).Find(&user1).Error
	if err != nil {
		return err
	}
	if user1.Username == "" {
		return http_code.ErrUserNotFound
	}
	return http_code.ErrUserFound
}

// DeleteUserForPay 退房前往结账 todo 应该开启事务
func (u *user) DeleteUserForPay(roomID int) (float64, int, error) {
	data, err := u.GetUser(roomID)
	if err != nil {
		return 0, 0, err
	}
	err = dao.DB.Debug().Where("room_identity = ?", roomID).Delete(&models.UserRoom{}).Error
	if err != nil {
		return 0, 0, err
	}
	err = dao.DB.Debug().Where("document_id = ?", data.DocumentIdentity).Delete(&models.UserBasic{}).Error
	if err != nil {
		return 0, 0, err
	}
	err = Room.UpdateRoomStatus(data.Room, http_code.RoomStatusFree)
	price := data.Room.Price * float64(Utils.GetTimeDay(data.StartTime))
	deposit := data.Room.Deposit

	checkOut := &models.CheckOut{
		Price:        price,
		Deposit:      deposit,
		Username:     data.User.Username,
		RoomID:       data.RoomIdentity,
		DocumentType: data.User.DocumentType,
		DocumentID:   data.DocumentIdentity,
		LeaveTime:    time.Now(),
	}
	err = dao.DB.Debug().Create(&checkOut).Error
	if err != nil {
		return 0, 0, err
	}
	return price, deposit, nil
}

// DeleteUserBook 解除预订
func (u *user) DeleteUserBook(roomID int) (float64, int, error) {
	data, err := u.GetUser(roomID)
	if err != nil {
		return 0, 0, err
	}
	err = dao.DB.Unscoped().Debug().Where("room_identity = ?", roomID).Delete(&models.UserRoom{}).Error
	if err != nil {
		return 0, 0, err
	}
	err = dao.DB.Unscoped().Debug().Where("document_id = ?", data.DocumentIdentity).Delete(&models.UserBasic{}).Error
	if err != nil {
		return 0, 0, err
	}
	err = Room.UpdateRoomStatus(data.Room, http_code.RoomStatusFree)
	price := data.Room.Price * float64(Utils.GetTimeDay(data.StartTime))
	deposit := data.Room.Deposit

	return price, deposit, nil
}

func (u *user) GetUser(roomID int) (*models.UserRoom, error) {
	var userRoom *models.UserRoom
	err := dao.DB.Debug().Preload("Room").Preload("User").Where("room_identity = ?", roomID).Find(&userRoom).Error
	if err != nil {
		return nil, err
	}
	if userRoom.ID == 0 {
		return nil, http_code.ErrUserNotFound
	}
	return userRoom, nil
}

// LivingInfo 查询所有在住客人
func (u *user) LivingInfo() ([]*models.UserRoom, error) {
	var data []*models.UserRoom
	err := dao.DB.Debug().Preload("Room").Preload("User").Where("start_time < ?", time.Now().Format("2006-01-02 15:04:05")).Find(&data).Error
	return data, err
}

// BookInfo 查询所有预订客人
func (u *user) BookInfo() ([]*models.UserRoom, error) {
	var data []*models.UserRoom
	err := dao.DB.Debug().Preload("Room").Preload("User").Where("start_time > ?", time.Now().Format("2006-01-02 15:04:05")).Find(&data).Error
	return data, err
}

// HistoryInfo 查询历史在住客人
func (u *user) HistoryInfo() ([]*models.UserRoom, error) {
	var data []*models.UserRoom
	err := dao.DB.Unscoped().Debug().Preload("Room").Preload("User").Where("deleted_at < ?", time.Now().Format("2006-01-02 15:04:05")).Find(&data).Error
	return data, err
}

// PayInfo 退房结账统计
func (u *user) PayInfo() ([]*models.CheckOut, error) {
	var data []*models.CheckOut
	err := dao.DB.Debug().Find(&data).Error
	return data, err
}

// BookRoomInfo 退房结账统计
func (u *user) BookRoomInfo() ([]*models.UserRoom, error) {
	var data []*models.UserRoom
	err := dao.DB.Unscoped().Debug().Preload("User").Where("created_at != start_time").Find(&data).Error
	if err != nil {
		return nil, err
	}
	var data2 []*models.UserRoom
	for _, value := range data {
		if !Utils.CompareTime(value.StartTime, value.CreatedAt) {
			data2 = append(data2, value)
		}
	}
	return data2, nil
}
