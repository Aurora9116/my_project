package service

import (
	"gorm.io/gorm"
	"system_work/dao"
	"system_work/http_code"
	"system_work/models"
)

type room struct{}

var Room = new(room)

// CheckRoom 查找是否有空闲的房间
func (r *room) CheckRoom(roomType string, roomID int) (*models.RoomBasic, error) {
	var data *models.RoomBasic

	// 用户指定房间号
	if roomID != 0 {
		status, err := r.CheckRoomStatus(roomID)
		if err != nil {
			return nil, err
		}
		// 指定房间存在
		if status == http_code.RoomStatusFree {
			err = dao.DB.Where("room_id = ?", roomID).Find(&data).Error
			if err != nil {
				return nil, err
			}
			return data, nil
		}

	}
	// 指定房间不存在或被占用
	err := dao.DB.Debug().Where("room_type = ? and status = 0", roomType).First(&data).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	if data.RoomID == 0 {
		return nil, http_code.ErrRoomNotFree
	}
	return data, nil
}

// 录入房间
func addRoom(data *models.RoomBasic) error {
	return dao.DB.Debug().Create(&data).Error
}

// AddRoom 录入房间
func (r *room) AddRoom(data *models.RoomBasic) error {
	code, err := r.CheckRoomStatus(data.RoomID)
	if err != nil {
		return err
	}
	if code != http_code.RoomStatusNotExist {
		return http_code.ErrRoomFound
	}
	err = addRoom(data)
	if err != nil {
		return err
	}
	return nil
}

// DeleteRoom 清除意外输入房间--慎用
func (r *room) DeleteRoom(roomID int) error {
	status, err := r.CheckRoomStatus(roomID)
	if err != nil {
		return err
	}
	if status == -1 {
		return http_code.ErrRoomNotFound
	}
	if status == 1 {
		return http_code.ErrRoomOccupied
	}
	if status == 2 {
		return http_code.ErrRoomWillOccupied
	}
	if status != 0 {
		return http_code.ErrRoomStatus
	}
	err = dao.DB.Where("room_id = ?", roomID).Delete(&models.RoomBasic{}).Error
	return err
}

// UpdateRoomStatus 更新房间状态 todo---预订，直接开房
func (r *room) UpdateRoomStatus(roomData *models.RoomBasic, roomStatus int) error {
	err := dao.DB.Debug().Model(&models.RoomBasic{}).Where("room_id = ?", roomData.RoomID).Update("status", roomStatus).Error
	return err
}

// 返回房间状态
func getRoomStatus(status int) string {
	return http_code.RoomStatus(status)
}

// GetRoomStatus 查看房间状态
func (r *room) GetRoomStatus(roomID int) (string, error) {
	status, err := r.CheckRoomStatus(roomID)
	if err != nil {
		return "", err
	}
	message := getRoomStatus(status)
	return message, nil
}

// CheckRoomStatus 检查房间状态
func (r *room) CheckRoomStatus(roomID int) (int, error) {
	var room1 *models.RoomBasic
	err := dao.DB.Where("room_id = ?", roomID).Find(&room1).Error
	if err != nil {
		return -2, err
	}
	if room1.RoomID == 0 {
		return http_code.RoomStatusNotExist, nil
	}
	return room1.Status, nil
}

// todo 查找所有空余房间
