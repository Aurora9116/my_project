package models

import (
	"gorm.io/gorm"
	"time"
)

type UserRoom struct {
	gorm.Model
	DocumentIdentity string     `json:"document_identity" gorm:"column:document_identity;type:varchar(100)"`
	RoomIdentity     int        `json:"room_identity" gorm:"column:room_identity;type:int(100)"`
	StartTime        time.Time  `json:"start_time" gorm:"column:start_time;type:datetime(3)"`       // 入住时期
	ExLeaveTime      time.Time  `json:"ex_leave_time" gorm:"column:ex_leave_time;type:datetime(3)"` // 预计离开日期
	Room             *RoomBasic `gorm:"foreignKey:room_identity;references:room_id"`
	User             *UserBasic `gorm:"foreignKey:document_identity;references:document_id"`
}

func (*UserRoom) TableName() string {
	return "user_room"
}
