package initialize

import (
	"log"
	"system_work/dao"
	"system_work/initialize/init_all"
)

func Init() {
	dao.InitMysql()
	r := init_all.Router()
	if err := r.Run(":9999"); err != nil {
		log.Println("r.Run() err:", err)
	}
}
