package api

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
	"system_work/http_code"
	"system_work/models"
	"system_work/service"
	"time"
)

type user struct {
}

var User = new(user)

// AddUser 开房登记
func (*user) AddUser(c *gin.Context) {
	var data models.Appointment
	err := c.ShouldBindJSON(&data)
	fmt.Println(data)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	data.StartTime = time.Now().Format("2006-01-02 15:04:05")
	Utils.AddUser(c, data, http_code.RoomStatusOccupied)
}

// DeleteUserForPay 退房前往结账（仅退房并放回价格及押金）
func (*user) DeleteUserForPay(c *gin.Context) {
	roomID, err := strconv.Atoi(c.PostForm("roomID"))
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}
	price, deposit, err := service.User.DeleteUserForPay(roomID)
	if err != nil {
		Utils.ErrJSON(c, http.StatusOK, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"code":    200,
		"price":   price,   // 应付金额
		"deposit": deposit, // 押金
	})
}
