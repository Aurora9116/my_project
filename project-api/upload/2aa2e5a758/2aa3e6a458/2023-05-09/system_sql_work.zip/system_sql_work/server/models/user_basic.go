package models

import "gorm.io/gorm"

type UserBasic struct {
	gorm.Model
	Username     string `json:"username" gorm:"column:username;type:varchar(100)"`
	Sex          string `json:"sex" gorm:"column:sex;type:varchar(10)"`
	DocumentType string `json:"document_type" gorm:"column:document_type;type:varchar(100)"`    // 证件类型
	DocumentID   string `json:"document_id" gorm:"index;column:document_id;type:varchar(100);"` // 证件号
	Phone        int    `json:"phone" gorm:"column:phone;type:int"`
}

func (*UserBasic) TableName() string {
	return "user_basic"
}
