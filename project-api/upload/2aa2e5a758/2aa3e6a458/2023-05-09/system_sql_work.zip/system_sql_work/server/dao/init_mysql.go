package dao

import (
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"log"
	"system_work/conf"
	"system_work/models"
)

var DB *gorm.DB
var err error

func InitMysql() {
	config := conf.GetConf().Mysql
	DB, err = gorm.Open(mysql.Open(config.Dsn), &gorm.Config{})
	if err != nil {
		log.Println(err)
	}
	_ = DB.AutoMigrate(&models.UserRoom{}, &models.RoomBasic{}, &models.UserBasic{}, &models.Admin{}, &models.CheckOut{})
	//fmt.Println("conf.Dsn:", conf.Dsn)
}
