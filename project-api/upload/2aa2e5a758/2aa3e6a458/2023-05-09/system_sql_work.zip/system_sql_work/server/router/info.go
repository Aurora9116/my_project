package router

import (
	"github.com/gin-gonic/gin"
	"system_work/api"
)

type Info struct {
}

// InfoGroup 预订
func (*Info) InfoGroup(routerGroup *gin.RouterGroup) {
	infoGroup := routerGroup.Group("/info")
	{
		infoGroup.GET("/living", api.Info.LivingInfo)
		infoGroup.GET("/book", api.Info.BookInfo)
		infoGroup.GET("/history", api.Info.HistoryInfo)
	}
}
