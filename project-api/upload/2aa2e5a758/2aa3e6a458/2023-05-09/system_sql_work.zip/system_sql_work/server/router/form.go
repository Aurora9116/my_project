package router

import (
	"github.com/gin-gonic/gin"
	"system_work/api"
)

type Form struct {
}

// FormGroup 预订
func (*Form) FormGroup(routerGroup *gin.RouterGroup) {
	formGroup := routerGroup.Group("/form")
	{
		formGroup.GET("/history", api.Form.HistoryRoomInfo)
		formGroup.GET("/pay", api.Form.PayInfo)
		formGroup.GET("/book", api.Form.BookRoomInfo)
	}
}
