package models

import (
	"gorm.io/gorm"
)

type Appointment struct {
	gorm.Model
	Username     string  `json:"username"`
	Sex          string  `json:"sex"`
	DocumentType string  `json:"documentType"` // 证件类型
	DocumentID   string  `json:"documentID"`   // 证件号
	Phone        int     `json:"phone"`
	RoomID       int     `json:"roomID"`
	RoomType     string  `json:"roomType"`
	Price        float64 `json:"price"`
	StartTime    string  `json:"startTime"`
	ExLeaveTime  string  `json:"ex_leave_time"`
}
