package init_all

import (
	"github.com/gin-gonic/gin"
	"system_work/middlerware"
	"system_work/router"
)

func Router() *gin.Engine {
	r := gin.Default()

	RouterGroup := r.Group("/")
	AdminGroup := r.Group("/")
	AdminGroup.Use(middlerware.JwtToken())
	{
		router.Router.ReceptionGroup(AdminGroup)
		router.Router.BookGroup(AdminGroup)
		router.Router.AdminGroup(RouterGroup)
		router.Router.InfoGroup(AdminGroup)
		router.Router.FormGroup(AdminGroup)
	}
	return r
}
